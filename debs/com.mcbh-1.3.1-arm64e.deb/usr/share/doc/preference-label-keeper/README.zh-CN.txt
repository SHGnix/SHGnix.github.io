名称保护 1.3.1 首页分组卡片测试包（iOS 15+，RootHide）

同包名覆盖1.3.x升级，不要先卸载；没有1.4的照片头像功能。
保留设置界面，不再使用自身 PreferenceLabelKeeper.bundle 目录。
设置入口和页面标题为“名称保护”，不带（Roothide）。
本插件设置logo配套29×29、58×58、87×87像素PNG（1x/2x/3x，常规29pt）；
入口引用icon.png基础资源，58×58二倍资源像素与上传1.3.1完全一致。
最终实际显示仍由系统设置布局和缓存决定。

首页保留总开关，每个插件使用一张系统分组卡片，直接列出“保护此插件”和
“自定义名称”，不再点进子页面。每张卡片上方显示已记录的插件名，不显示长路径。
布局使用PreferenceLoader的原生PSGroupCell分节，圆角、留白和开关由当前系统绘制；
不强行复制截图字体或像素尺寸，不加入新dylib、常驻进程或自身.bundle。
本版不再生成PreferenceLabelKeeper.page-<64位摘要>.plist子页面；上版残留页面
不含entry，且继续排除扫描，不会产生额外设置入口或影响名称保护。
保留原偏好域和摘要键，原开关/自定义名称不变。
卸载仅额外清理旧版生成的子页面文件；名称快照和用户偏好不删除。

新增按 entry.bundle 识别的名称保护：
- KayokoPreferences：便捷剪切
- TVZPrefs：录屏轨迹
无需将上传文件放进本包；不写死Root.plist/Root_1.plist这两个上传文件名。
在 /Library/PreferenceLoader/Preferences 内递归扫描普通plist，包括资源bundle子目录。
只解析含有效entry.label的设置入口；不递归跟随符号链接，不扫描插件代码bundle内部设置页。
不同目录下同名Root.plist使用完整相对路径区分，不会互相覆盖记录。

上述两插件首次被记录时使用本次上传文件中的中文名称；既有名称快照、自定义名称、
总开关和逐插件开关保持原样，自定义名称优先。显式选择的这两bundle可在关闭
自动收录新插件时仍新建记录，但不会绕过总开关/逐项关闭。
其他插件仍按当前名称自动记录，不会随意改成上传样本的名称。
仅恢复entry.label，其余字段、bundle身份和plist格式不变，不替换整个旧文件。
首次检测时若是configure/restore/triggered且保护启用，可立即应用这两项默认名；
refresh仅刷新列表，capture明确重新记录当下名称，二者均不改第三方名称。

名称状态升级为schema2，兼容读取schema1并保留旧的一级路径和偏好键。
升级前状态备份：/var/lib/preference-label-keeper/names.before-schema2.json（只存一次）。
当前状态：/var/lib/preference-label-keeper/names.json。
偏好域保持local.preference-label-keeper.ui，不删除旧自定义开关/名称。
旧1.3.0-3或更早CLI不认识schema2，直接降级不能使用新状态；需先备份全部状态，
按升级前备份恢复schema1后才可降级（会丢失升级后新增记录）。不要直接删除names.json。

安装后彻底退出再打开“设置”。立即应用：在RootHide root终端运行
preference-label-keeper restore，然后重开设置。
若插件尚未安装或入口不在PreferenceLoader扫描范围，将不会凭样本生成假安装条目；
安装后再次触发或执行restore/refresh检测。
status仅查看；refresh刷新列表；capture重记当前基准，意外名称被覆盖时不要使用。

本地验证不代表iOS真机验证；设置界面、绝对图标路径、RootHide根、触发器和缓存需实机确认。
此包不对plist进行密码学加密；二进制plist依旧可解析。
