SHG

1.3.0 RootHide 原生测试版，iOS 15+。无需安装 Python。PreferenceLoader 仅用于设置入口。原有快照和开关保持兼容。可使用 preference-label-keeper status / restore / capture / refresh。请勿在名称被意外覆盖时执行 capture。未做真机运行测试。
